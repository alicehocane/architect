import React, { useEffect } from 'react';
import { Architect } from '../types';

interface ProfilePageProps {
  architect: Architect;
  onBackClick: () => void;
}

const ProfilePage: React.FC<ProfilePageProps> = ({ architect, onBackClick }) => {
  useEffect(() => {
    const script = document.createElement('script');
    script.type = 'application/ld+json';
    
    const locationSchemas = architect.Locations.map(loc => ({
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "@id": `https://designdirectory.pk/#architects/${architect.slug}/${loc.citySlug}`,
      "name": `${architect["Shop Name"]} - ${loc.City} Studio`,
      "image": `https://picsum.photos/seed/${architect.slug}/600/600`,
      "telephone": loc["Phone Number"],
      "url": architect.Website || `https://designdirectory.pk/#architects/${architect.slug}`,
      "hasMap": loc["Map URL"],
      "priceRange": "$$$",
      "address": {
        "@type": "PostalAddress",
        "addressLocality": loc.City,
        "addressCountry": "PK"
      },
      "aggregateRating": loc.Rating ? {
        "@type": "AggregateRating",
        "ratingValue": loc.Rating,
        "reviewCount": loc.Reviews || 1
      } : undefined,
      "parentOrganization": {
        "@type": "Organization",
        "name": architect["Shop Name"],
        "url": architect.Website || "https://designdirectory.pk"
      }
    }));

    const breadcrumbSchema = {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://designdirectory.pk" },
        { "@type": "ListItem", "position": 2, "name": "Architects", "item": "https://designdirectory.pk/#cities" },
        { "@type": "ListItem", "position": 3, "name": architect["Shop Name"] }
      ]
    };
    
    script.text = JSON.stringify([...locationSchemas, breadcrumbSchema]);
    document.head.appendChild(script);
    return () => { document.head.removeChild(script); };
  }, [architect]);

  const hasMultipleLocations = architect.Locations.length > 1;

  return (
    <div className="max-w-[1024px] mx-auto px-6 py-12 pb-32 page-transition">
      <button 
        onClick={onBackClick}
        className="flex items-center gap-2 text-[#0066cc] mb-12 hover:underline text-[17px] font-medium group"
      >
        <svg className="w-4 h-4 group-hover:-translate-x-1 transition-transform" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="m15 18-6-6 6-6"/></svg>
        Back to directory
      </button>

      <div className="mb-20">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-8">
          <div>
            <span className="text-[13px] font-bold text-[#0066cc] uppercase tracking-[0.15em] mb-4 block">
              {architect.Category || 'Architectural Practice'}
            </span>
            <h1 className="text-[48px] sm:text-[64px] font-bold text-[#1d1d1f] tracking-tight leading-none mb-4">
              {architect["Shop Name"]}
            </h1>
            <div className="flex flex-wrap items-center gap-4 text-[19px] text-[#86868b] font-light">
              <div className="flex items-center gap-2">
                <svg className="w-5 h-5 text-[#ff9500] fill-current" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
                <span className="font-semibold text-[#1d1d1f]">{architect.globalRating?.toFixed(1) || 'Elite'}</span> Brand Rating
              </div>
              <span className="w-1 h-1 rounded-full bg-[#d2d2d7]"></span>
              <span className="font-medium text-[#1d1d1f]">{architect.Locations.length} Regional Branches</span>
            </div>
          </div>
          
          {architect.Website && (
            <a 
              href={architect.Website} 
              target="_blank" 
              rel="noopener" 
              className="inline-flex items-center gap-3 bg-[#0071e3] text-white px-8 py-4 rounded-full text-[17px] font-semibold hover:bg-[#0077ed] transition-all shadow-xl shadow-blue-500/10 active:scale-95"
            >
              Visit Practice Website
              <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
            </a>
          )}
        </div>
      </div>

      <section className="mb-24">
        <div className="flex items-center justify-between mb-10">
          <h2 className="text-[32px] font-bold tracking-tight text-[#1d1d1f]">
            {hasMultipleLocations ? 'Find a Local Studio' : 'Our Studio Location'}
          </h2>
          {hasMultipleLocations && (
            <span className="text-[14px] text-[#86868b] font-medium bg-[#f5f5f7] px-4 py-2 rounded-full">
              {architect.Locations.length} Active Branches
            </span>
          )}
        </div>
        
        <div className={`grid gap-8 ${hasMultipleLocations ? 'grid-cols-1 md:grid-cols-2' : 'grid-cols-1'}`}>
          {architect.Locations.map((loc, idx) => (
            <div 
              key={idx} 
              className="bg-white rounded-[2.5rem] p-10 border border-[#d2d2d7]/60 shadow-sm flex flex-col justify-between group hover:border-[#0071e3] transition-all duration-500"
            >
              <div className="flex-1">
                <div className="flex justify-between items-start mb-6">
                  <div>
                    <h3 className="text-[24px] font-bold text-[#1d1d1f] mb-2">{loc.City} Branch</h3>
                    <p className="text-[17px] text-[#86868b] font-medium mb-4">
                      {loc["Phone Number"] || 'Direct Line Pending'}
                    </p>
                  </div>
                  {loc.Rating && (
                    <div className="flex items-center gap-1.5 bg-[#f5f5f7] px-4 py-2 rounded-full ring-1 ring-black/5">
                      <svg className="w-4 h-4 text-[#ff9500] fill-current" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
                      <span className="font-bold text-[15px]">{loc.Rating.toFixed(1)}</span>
                    </div>
                  )}
                </div>
                
                <div className="flex flex-wrap gap-3 mt-8">
                  {loc["Phone Number"] && (
                    <a 
                      href={`tel:${loc["Phone Number"]}`}
                      className="inline-flex items-center justify-center gap-2 bg-[#f5f5f7] text-[#1d1d1f] px-6 py-3 rounded-2xl font-semibold hover:bg-[#e5e5e7] transition-all active:scale-95"
                    >
                      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
                      Call Branch
                    </a>
                  )}
                  {loc["Map URL"] && (
                    <a 
                      href={loc["Map URL"]} 
                      target="_blank" 
                      rel="noopener"
                      className="inline-flex items-center justify-center gap-2 bg-white text-[#0066cc] border border-[#d2d2d7] px-6 py-3 rounded-2xl font-semibold hover:bg-[#f5f5f7] transition-all active:scale-95"
                    >
                      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
                      Get Directions
                    </a>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-16 border-t border-[#d2d2d7]/30 pt-20">
        <div className="lg:col-span-2 space-y-12">
          <div>
            <h3 className="text-[28px] font-bold text-[#1d1d1f] mb-6">Expertise & Regional Presence</h3>
            <p className="text-[21px] text-[#424245] leading-relaxed font-light">
              As a unified architectural practice operating in {architect.Locations.map(l => l.City).join(', ')}, {architect["Shop Name"]} maintains a commitment to architectural innovation tailored to local urban conditions. 
              Their integrated studio model ensures that whether your project is in {architect.Locations[0].City} or a regional hub, you receive the same gold-standard expertise.
            </p>
          </div>
          
          <div className="p-12 bg-[#f5f5f7] rounded-[3rem] border border-[#e5e5e7] flex flex-col md:flex-row items-center gap-8 shadow-sm">
             <div className="flex-1">
               <h4 className="text-[26px] font-bold text-[#1d1d1f] mb-2 tracking-tight">Get a Free Project Estimate</h4>
               <p className="text-[#86868b] font-light text-[18px]">No obligation • Expert-led review by AAK Architects</p>
             </div>
             <a 
               href="https://api.whatsapp.com/send/?phone=923215201830&text=Hello%20AAK%20Architects%2C%20I%E2%80%99d%20like%20to%20request%20a%20free%20project%20estimate%20and%20discuss%20my%20architectural%20requirements."
               target="_blank"
               rel="noopener noreferrer"
               className="bg-[#0071e3] text-white px-10 py-5 rounded-2xl font-bold hover:bg-[#0077ed] transition-all shadow-xl shadow-blue-500/10 active:scale-95 whitespace-nowrap text-[18px]"
             >
               Free Estimate
             </a>
          </div>
        </div>
        
        <div className="space-y-10">
           <h3 className="text-[24px] font-bold text-[#1d1d1f]">Practice Standards</h3>
           <ul className="space-y-6">
              {[
                { title: 'Verified Footprint', desc: 'Legitimate physical branch presence' },
                { title: 'Portfolio Quality', desc: 'Curated architectural track record' },
                { title: 'Professional Registration', desc: 'Complying with local design codes' },
                { title: 'Technical Mastery', desc: 'Expert engineering & design teams' }
              ].map((item, i) => (
                <li key={i} className="flex gap-4">
                   <div className="mt-1 w-6 h-6 rounded-full bg-blue-50 flex items-center justify-center text-[#0066cc] flex-shrink-0">
                      <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                   </div>
                   <div>
                      <h4 className="font-bold text-[#1d1d1f] text-[16px]">{item.title}</h4>
                      <p className="text-[14px] text-[#86868b]">{item.desc}</p>
                   </div>
                </li>
              ))}
           </ul>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;