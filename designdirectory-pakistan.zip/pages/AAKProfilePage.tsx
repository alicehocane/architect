
import React, { useEffect } from 'react';

interface AAKProfilePageProps {
  onBackClick: () => void;
}

const AAKProfilePage: React.FC<AAKProfilePageProps> = ({ onBackClick }) => {
  useEffect(() => {
    // SEO: Schema.org Structured Data
    const script = document.createElement('script');
    script.type = 'application/ld+json';
    const schema = {
      "@context": "https://schema.org",
      "@type": ["ProfessionalService", "Organization"],
      "name": "AAK Architects",
      "legalName": "AAK Architects",
      "url": "https://designdirectory.pk/#architects/aak-architects",
      "logo": "https://designdirectory.pk/logo.png",
      "description": "Design-led architecture practice committed to creating context-responsive, sustainable, and research-informed spaces.",
      "founder": {
        "@type": "Person",
        "name": "Ayyaz Ahmed Karni",
        "jobTitle": "Principal Architect & Founder",
        "alumniOf": [
          {
            "@type": "CollegeOrUniversity",
            "name": "Sapienza University of Rome"
          },
          {
            "@type": "CollegeOrUniversity",
            "name": "Purdue University"
          },
          {
            "@type": "CollegeOrUniversity",
            "name": "Riphah International University"
          },
          {
            "@type": "CollegeOrUniversity",
            "name": "COMSATS University Islamabad"
          }
        ]
      },
      "knowsAbout": ["Sustainable Architecture", "Agritecture", "Urban Planning", "Climate Responsive Design"],
      "address": {
        "@type": "PostalAddress",
        "addressLocality": "Rawalpindi",
        "addressCountry": "PK"
      },
      "telephone": "+923215201830"
    };

    script.text = JSON.stringify(schema);
    document.head.appendChild(script);
    return () => { document.head.removeChild(script); };
  }, []);

  return (
    <div className="max-w-[1024px] mx-auto px-6 py-12 pb-32 page-transition">
      <button 
        onClick={onBackClick}
        className="flex items-center gap-2 text-[#0066cc] mb-12 hover:underline text-[17px] font-medium group"
      >
        <svg className="w-4 h-4 group-hover:-translate-x-1 transition-transform" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="m15 18-6-6 6-6"/></svg>
        Back to directory
      </button>

      {/* Hero Header */}
      <header className="mb-24">
        <div className="flex flex-col md:flex-row justify-between items-start gap-12">
          <div className="max-w-2xl">
            <span className="inline-block px-4 py-1.5 rounded-full bg-[#f5f5f7] text-[#86868b] text-[12px] font-bold uppercase tracking-widest mb-6">
              Elite Architectural Practice
            </span>
            <h1 className="text-[56px] sm:text-[72px] font-bold tracking-tight text-[#1d1d1f] leading-[1.05] mb-6">
              Ayyaz Ahmed <br className="hidden sm:block" /> Karni
            </h1>
            <p className="text-[22px] sm:text-[28px] text-[#424245] font-light leading-relaxed mb-8">
              Founder & Principal Architect – <span className="font-semibold text-[#1d1d1f]">AAK Architects</span>
            </p>
            <div className="flex flex-wrap gap-4 text-[#86868b] text-[15px] font-medium">
              <span className="flex items-center gap-2">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
                Architect
              </span>
              <span className="w-1 h-1 rounded-full bg-[#d2d2d7] mt-2.5"></span>
              <span className="flex items-center gap-2">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/></svg>
                Researcher
              </span>
              <span className="w-1 h-1 rounded-full bg-[#d2d2d7] mt-2.5"></span>
              <span className="flex items-center gap-2">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M12 21a9.004 9.004 0 008.716-6.747M12 21a9.004 9.004 0 01-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9s2.015-9 4.5-9M3.284 14.253A8.918 8.918 0 013 12c0-4.478 3.277-8.203 7.596-8.92m10.12 10.173A8.918 8.918 0 0021 12c0-4.478-3.277-8.203-7.596-8.92"/></svg>
                Sustainable Design Strategist
              </span>
            </div>
          </div>
          
          <div className="flex flex-col gap-4 w-full md:w-auto">
            <a 
              href="https://api.whatsapp.com/send/?phone=923215201830&text=Hello%20AAK%20Architects%2C%20I%E2%80%99m%20looking%20for%20architectural%20consultancy%20and%20would%20like%20to%20discuss%20my%20project."
              target="_blank"
              className="bg-[#0071e3] text-white px-8 py-5 rounded-2xl font-bold hover:bg-[#0077ed] transition-all text-center shadow-xl shadow-blue-500/10 active:scale-95 flex items-center justify-center gap-2"
            >
              Start Collaboration
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="m9 18 6-6-6-6"/></svg>
            </a>
            <p className="text-[#86868b] text-[13px] text-center font-medium">Available for Global & Local Inquiries</p>
          </div>
        </div>
      </header>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
        
        <div className="lg:col-span-2 space-y-16">
          {/* About Section */}
          <section>
            <h2 className="text-[28px] font-bold text-[#1d1d1f] mb-6">Design Philosophy</h2>
            <div className="text-[19px] text-[#424245] leading-relaxed space-y-6 font-light">
              <p>
                Ayyaz Ahmed Karni is an architect, researcher, and visiting scholar at <span className="font-semibold text-[#1d1d1f]">Purdue University (USA)</span>, pursuing a PhD in Engineering-Based Architecture and Urban Planning at <span className="font-semibold text-[#1d1d1f]">Sapienza University of Rome</span>, Italy.
              </p>
              <p>
                As the founder of AAK Architects, Ayyaz brings together design excellence, research-driven thinking, and real-world constructability to deliver architecture that is visually compelling, socially impactful, and environmentally sustainable.
              </p>
            </div>
          </section>

          {/* Research Section */}
          <section className="bg-[#f5f5f7] rounded-[3.5rem] p-10 sm:p-14 border border-[#e5e5e7]">
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-10 rounded-full bg-[#0066cc]/10 flex items-center justify-center text-[#0066cc]">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24"><path d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.183.244l-.28.19a2 2 0 00-.987 1.706V21h17.14v-1.432a2 2 0 00-.595-1.414l-1.314-1.314zM12 11a4 4 0 100-8 4 4 0 000 8z"/></svg>
              </div>
              <h2 className="text-[28px] font-bold text-[#1d1d1f]">Agritecture & Sustainability</h2>
            </div>
            <p className="text-[18px] text-[#424245] leading-relaxed mb-10 font-light italic">
              “Fostering Agritecture: A Sustainable Approach to Overcome Housing Shortage and Food Insecurity in Pakistan”
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
               {[
                 { title: 'Housing Shortage', desc: 'Solving density in urbanizing regions.' },
                 { title: 'Food Security', desc: 'Preserving loss of arable land.' },
                 { title: 'Climate Response', desc: 'Resource-efficient design systems.' },
                 { title: 'Resilience', desc: 'Sustainable urban-rural integration.' }
               ].map((item, i) => (
                 <div key={i} className="bg-white p-6 rounded-3xl border border-black/5">
                    <h4 className="font-bold text-[#1d1d1f] mb-1">{item.title}</h4>
                    <p className="text-[14px] text-[#86868b]">{item.desc}</p>
                 </div>
               ))}
            </div>
          </section>

          {/* Core Services Section */}
          <section>
            <h2 className="text-[28px] font-bold text-[#1d1d1f] mb-8">AAK Architects – Design with Purpose</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-12 gap-y-10">
               {[
                 { title: 'Residential & Housing', icon: 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6' },
                 { title: 'Sustainable Architecture', icon: 'M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z' },
                 { title: 'Urban Planning', icon: 'M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4' },
                 { title: 'Concept Consultancy', icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01' }
               ].map((service, i) => (
                 <div key={i} className="flex gap-6 items-start group">
                    <div className="w-12 h-12 rounded-2xl bg-[#f5f5f7] flex items-center justify-center text-[#1d1d1f] group-hover:bg-[#0071e3] group-hover:text-white transition-all duration-300 flex-shrink-0">
                      <svg className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d={service.icon}/></svg>
                    </div>
                    <div>
                      <h4 className="text-[20px] font-bold text-[#1d1d1f] mb-2">{service.title}</h4>
                      <p className="text-[15px] text-[#86868b] leading-relaxed">Tailored architectural solutions grounded in global best practices and local realities.</p>
                    </div>
                 </div>
               ))}
            </div>
          </section>
        </div>

        {/* Sidebar - Professional Background */}
        <aside className="space-y-12">
          <div className="p-8 bg-white rounded-[2.5rem] border border-[#d2d2d7]/60 shadow-sm">
            <h3 className="text-[22px] font-bold text-[#1d1d1f] mb-8">Academic Timeline</h3>
            <div className="space-y-8 relative">
              <div className="absolute left-[11px] top-2 bottom-2 w-0.5 bg-[#f5f5f7]"></div>
              
              {[
                { date: '2023 – Ongoing', title: 'PhD Engineering-Based Architecture', org: 'Sapienza University of Rome, Italy' },
                { date: 'Current', title: 'Visiting Scholar', org: 'Purdue University, USA' },
                { date: '2020', title: 'MS Project Management', org: 'Riphah International University' },
                { date: '2018', title: 'Bachelor of Architecture', org: 'COMSATS University Islamabad' },
                { date: '2012', title: 'DAE Civil Engineering', org: 'Swedish Institute of Tech' }
              ].map((item, i) => (
                <div key={i} className="relative pl-10">
                  <div className={`absolute left-0 top-1.5 w-6 h-6 rounded-full border-4 border-white shadow-sm ${i === 0 ? 'bg-[#0071e3]' : 'bg-[#d2d2d7]'}`}></div>
                  <span className="block text-[12px] font-bold text-[#86868b] uppercase tracking-wider mb-1">{item.date}</span>
                  <h4 className="text-[15px] font-bold text-[#1d1d1f] leading-tight mb-0.5">{item.title}</h4>
                  <p className="text-[14px] text-[#86868b]">{item.org}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="p-8 bg-white rounded-[2.5rem] border border-[#d2d2d7]/60 shadow-sm">
            <h3 className="text-[22px] font-bold text-[#1d1d1f] mb-6">Certifications</h3>
            <div className="flex items-center gap-4 p-4 rounded-2xl bg-[#f5f5f7] border border-black/5">
              <div className="w-10 h-10 rounded-full bg-[#ff9500] flex items-center justify-center text-white text-[10px] font-bold">PCATP</div>
              <div>
                <h4 className="text-[14px] font-bold">Licensed Architect</h4>
                <p className="text-[12px] text-[#86868b]">Pakistan Council of Architects & Town Planners</p>
              </div>
            </div>
          </div>

          <div className="p-10 bg-[#1d1d1f] rounded-[2.5rem] text-white">
            <h3 className="text-[24px] font-bold mb-6">Let’s Build Something Meaningful</h3>
            <p className="text-[16px] text-white/70 font-light leading-relaxed mb-8">
              Whether exploring sustainable design or seeking consultancy, AAK Architects is ready to turn your vision into a future-ready reality.
            </p>
            <a 
              href="https://api.whatsapp.com/send/?phone=923215201830"
              className="block w-full text-center bg-white text-[#1d1d1f] py-4 rounded-xl font-bold hover:bg-[#f5f5f7] transition-colors active:scale-95"
            >
              Contact Studio
            </a>
          </div>
        </aside>

      </div>
    </div>
  );
};

export default AAKProfilePage;
